<h1>Halaman Edit</h1>

<form action="/posts/<?php echo e($post->id); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <label>Judul</label><br>
    <input type="text" name="judul" value="<?php echo e($post->judul); ?>">
    <br><br>

    <label>Isi</label><br>
    <textarea name="isi"><?php echo e($post->isi); ?></textarea>
    <br><br>

    <label>Gambar</label><br>
    <input type="file" name="gambar">
    <br><br>

    <button type="submit">Update</button>
</form><?php /**PATH C:\Users\LENOVO\belajar_laravel\resources\views/posts/edit.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>Belajar LaravelL</title>
</head>
<body>
    <h1>Header</h1>
    <?php echo $__env->yieldContent('content'); ?>
    <h3>Footer</h3>
</body>
</html><?php /**PATH C:\Users\LENOVO\belajar_laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>
<h1>Tambah Post</h1>

<form action="<?php echo e(route('posts.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <input type="text" name="judul" placeholder="Judul">
    <br><br>

    <textarea name="isi" placeholder="Isi"></textarea>
    <br><br>

    <input type="file" name="gambar">
    <br><br>

    <button type="submit">Simpan</button>
</form><?php /**PATH C:\Users\LENOVO\belajar_laravel\resources\views/posts/create.blade.php ENDPATH**/ ?>
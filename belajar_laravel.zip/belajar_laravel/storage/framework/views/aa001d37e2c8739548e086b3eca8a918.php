
<?php $__env->startSection('content'); ?>
    <h1>Hasil Input</h1>
    <h2>Halo, <?php echo e($nama); ?></h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LENOVO\belajar_laravel\resources\views/hasil.blade.php ENDPATH**/ ?>
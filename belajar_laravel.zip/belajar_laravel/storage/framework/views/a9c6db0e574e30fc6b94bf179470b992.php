

<?php $__env->startSection('content'); ?>

<h1>Edit Data</h1>

<form action="/biodata/<?php echo e($data->id); ?>" method="POST">

    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <input
        type="text"
        name="nama"
        value="<?php echo e($data->nama); ?>"
    >

    <br><br>

    <input
        type="number"
        name="umur"
        value="<?php echo e($data->umur); ?>"
    >

    <br><br>

    <textarea name="alamat"><?php echo e($data->alamat); ?></textarea>

    <br><br>

    <button type="submit">
        Update
    </button>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LENOVO\belajar_laravel\resources\views/biodata/edit.blade.php ENDPATH**/ ?>
<h1>Daftar Post</h1>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h3><?php echo e($post->judul); ?></h3>
    <p><?php echo e($post->isi); ?></p>
    <img src="<?php echo e(asset('storage/' .
$post->gambar)); ?>" width="200">
<br>
<a href="/posts/<?php echo e($post->id); ?>/edit">
    <button type="button">Edit</button>
</a>
<form action="/posts/<?php echo e($post->id); ?>" method="POST"
    style="display:inline;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit">Hapus</button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\LENOVO\belajar_laravel\resources\views/posts/index.blade.php ENDPATH**/ ?>
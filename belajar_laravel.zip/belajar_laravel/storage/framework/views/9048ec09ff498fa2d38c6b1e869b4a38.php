

<?php $__env->startSection('content'); ?>

<h1>Detail Biodata</h1>

<div>

    <h3><?php echo e($data->nama); ?></h3>

    <p>
        Umur : <?php echo e($data->umur); ?>

    </p>

    <p>
        Alamat : <?php echo e($data->alamat); ?>

    </p>

    <a href="/biodata">
        Kembali
    </a>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LENOVO\belajar_laravel\resources\views/biodata/show.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<h1>Data Biodata</h1>
<?php if(session('success')): ?>
<p style="color:green;">
    <?php echo e(session('success')); ?>

</p>
<?php endif; ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p>
        <?php echo e($item->nama); ?> - 
        <?php echo e($item->umur); ?> -
        <?php echo e($item->alamat); ?>

    </p>
    <form action="/biodata/<?php echo e($item->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

    <button type="submit">
        Hapus
</button>
</form>
<a href="/biodata/<?php echo e($item->id); ?>">
    Detail
</a>
<a href="/biodata/<?php echo e($item->id); ?>/edit">
    edit
</a>
<hr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LENOVO\belajar_laravel\resources\views/biodata/index.blade.php ENDPATH**/ ?>
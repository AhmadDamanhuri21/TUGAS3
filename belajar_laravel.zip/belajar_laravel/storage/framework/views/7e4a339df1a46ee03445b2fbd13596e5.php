
<?php $__env->startSection('content'); ?>
    <h1>Form, Input Nama</h1>
    
    <?php if($errors->any()): ?>
        <div style="color:red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="POST" action="/biodata">
        <?php echo csrf_field(); ?>
        <input type="text" name="nama"
placeholder="Masukkan nama"><br>
        <input type="number" name="umur"
placeholder="Masukkan umur"><br>
        <textarea name="alamat"
placeholder="Masukkan alamat"></textarea><br>

<?php if(session('success')): ?>
    <p style="color:green;">
        <?php echo e(session('success')); ?>

</p>
<?php endif; ?>
        
        
        <button type="submit">kirim</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LENOVO\belajar_laravel\resources\views/form.blade.php ENDPATH**/ ?>